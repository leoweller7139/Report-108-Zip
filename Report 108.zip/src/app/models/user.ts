export class User{ // Class Names should always have a capital.
    userName: string;
    email: string;
    password: string;
    firstName: string;
    lastName: string;
}