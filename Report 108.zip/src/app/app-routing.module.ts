import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// This gets auto generated when you put component: UserRegisterComponent
import { UserRegisterComponent } from './pages/user-register/user-register.component';
import { TempCalculatorComponent } from './components/temp-calculator/temp-calculator.component';
import { AboutComponent } from './pages/about/about.component';
import { UserListComponent } from './pages/user-list/user-list.component';
import { LoginComponent } from './pages/login/login.component';

// Register all Routes (paths) want the user to go to the page
const routes: Routes = [
  { path: 'user/register', component: UserRegisterComponent }, // Here
  { path: 'converter', component: TempCalculatorComponent },
  { path: 'about', component: AboutComponent },
  { path: 'user/list', component: UserListComponent },
  { path: 'login', component: LoginComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
