import { Component, OnInit } from '@angular/core';
import { User } from './../../models/user';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.scss']
})
export class UserRegisterComponent implements OnInit {

  model: User = new User();
  retypePassword : string;
  savedAlertVisible = false;

  constructor(private dataSrv: DataService ) { }

  ngOnInit() {
  }

  save(){
    console.log("Saving User", this.model);

    // save the user (this.model) into a service
    this.dataSrv.saveUser(this.model);

    // clear the form
    this.model = new User();
    this.retypePassword = null;
    this.savedAlertVisible = true;
  }

  isPasswordStrong(){
    //validate for password strongess
    var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
    return strongRegex.test(this.model.password);
  }


  isDataCorrect(){
    // Puts function from
    if(!this.isPasswordStrong()){
    return true; // <- button will be disabled
    }

    return !this.model.email 
    || !this.model.userName 
    || !this.model.password 
    || this.model.password.length < 6
    || !this.model.firstName
    || !this.model.lastName
    || this.model.password != this.retypePassword
  }

}
